<template>
  <div class="question">刷题</div>
</template>

<script>
export default {
  name: 'question'
}
</script>

<style></style>
